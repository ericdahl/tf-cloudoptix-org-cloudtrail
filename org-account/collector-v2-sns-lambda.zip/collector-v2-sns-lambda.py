import os
import logging
import requests
import gzip
import json
import boto3
import time
import io

s3 = boto3.resource('s3')

logger = logging.getLogger()
logger.setLevel(logging.INFO)

defaultValue = 'xxxx'
UUID = os.getenv('CUSTOMER_ID', defaultValue).strip()
DNS_PREFIX = os.getenv('DNS_PREFIX', defaultValue).strip()
DNS_PATH = os.getenv('DNS_PATH', defaultValue).strip()

def lambda_handler(event, context):
    if UUID == defaultValue or DNS_PREFIX == defaultValue or DNS_PATH == defaultValue:
        logger.error("Please check uuid, DNS_PREFIX and DNS_PATH in parameters")
        return
        
    for snsrecord in event["Records"]:
        for record in json.loads(snsrecord["Sns"]['Message'])["Records"]:
            data = {}
            data["s3Key"] = record["s3"]["object"]["key"]
            data["s3ObjectSize"] = record["s3"]["object"]["size"]
            data["bucket"] = record["s3"]["bucket"]["name"]
            data["region"] = record["awsRegion"]
            url = 'https://' + DNS_PREFIX + '/httpcollector/'+UUID+"/" +DNS_PATH
            accountId = context.invoked_function_arn.split(":")[4]
            headers = {"accountId": accountId}

            if "/cloudtrail-digest/" in data["s3Key"] or not data["s3Key"].endswith(".gz"):
                continue
            
            r = requests.post(url,  headers=headers, json = data )
            if r.status_code != requests.codes.ok :
                logger.error(r.text)
                raise Exception(str(r.status_code) + " " + r.text)
            
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

if __name__ == '__main__':
    lambda_handler(None, None) 
