"""
Expose version
"""

__version__ = "2.0.3"
VERSION = __version__.split('.')
